# virtual-board
This Python application enables users to write on a virtual board using hand gestures detected by a camera. Additionally, users can choose different colors for their writing.
